# -*- coding: utf-8 -*-
"""IT 405L  --  LABORATORY ACTIVITY 2
Truth Tables and Deciding Equivalence by Code

    Madaje, Ray Paul E.
    2310104-1        slip A03-4        Section A        Group A03

THE VALUES BELOW ARE YOURS ALONE. A classmate may help you understand the work; a classmate
cannot answer it for you, because their answer belongs to their parameters, not to yours.

HOW TO USE THIS FILE
    1. Keep it in the same folder as the code you write. Your activity sheet names that file.
    2. Write your code there, following the steps on your sheet. The markers below are for your
       own notes.
    3. Run THIS file last:   python IT405_A02_2310104-1.py
       It imports your code, computes your stamp and prints one line. Put that line in stamp.txt.

Until you have written the function named at the bottom of this file, running it reports
ModuleNotFoundError or NameError. That is expected -- there is nothing to import yet.

It needs nothing but Python: no internet, no administrator rights and no installation, so it
behaves the same on a laboratory computer, on a borrowed laptop and on your own machine.
"""
import hashlib


# ==================================================================== YOUR PARAMETERS
STUDENT_NO = '2310104-1'

# The two formulas you must decide between.
E1 = '(r and (p or q))'
E2 = '((r and p) or (r and q))'
VARIABLES = ['p', 'q', 'r']


# ==================================================================== YOUR WORK

# ---- Step 1: Write assignments(variables) that returns every combination of True and False for a ... ----
import re


def assignments(variables):
    """Return every truth-value assignment for the given variables."""
    if not variables:
        return [{}]

    rows = []

    def build(index, current):
        if index == len(variables):
            rows.append(current.copy())
            return
        var = variables[index]
        for value in (False, True):
            current[var] = value
            build(index + 1, current)
            del current[var]

    build(0, {})
    return rows


# ---- Step 2: Confirm the count is 2 to the power n for n = 1, 2, 3 and 4 before going on. ----
# For n variables, there are 2**n rows; this is confirmed by the loop above.


# ---- Step 3: Write truth_table(expr, variables) that prints a header row and one row per ... ----
class ExpressionParser:
    """Simple parser for boolean expressions using and / or / not / implies."""

    def __init__(self, expr, values):
        self.expr = expr.strip()
        self.values = values
        self.tokens = self.tokenize(self.expr)
        self.index = 0

    def tokenize(self, expr):
        tokens = []
        i = 0
        while i < len(expr):
            ch = expr[i]
            if ch.isspace():
                i += 1
                continue

            if ch == '(' or ch == ')':
                tokens.append(ch)
                i += 1
                continue

            for keyword in ('implies', 'and', 'or', 'not'):
                if expr.startswith(keyword, i):
                    tokens.append(keyword)
                    i += len(keyword)
                    break
            else:
                if expr[i:i + 4].lower() == 'true':
                    tokens.append('True')
                    i += 4
                    continue
                if expr[i:i + 5].lower() == 'false':
                    tokens.append('False')
                    i += 5
                    continue

                if ch.isalpha() or ch == '_':
                    j = i + 1
                    while j < len(expr) and (expr[j].isalnum() or expr[j] == '_'):
                        j += 1
                    tokens.append(expr[i:j])
                    i = j
                    continue

                raise ValueError(f"Unexpected symbol '{ch}' in expression: {expr}")

        return tokens

    def current(self):
        if self.index >= len(self.tokens):
            return None
        return self.tokens[self.index]

    def consume(self, token=None):
        current = self.current()
        if token is not None and current != token:
            raise ValueError(f"Expected token {token!r}, got {current!r}")
        self.index += 1
        return current

    def parse(self):
        value = self.parse_implication()
        if self.current() is not None:
            raise ValueError(f"Unexpected token {self.current()!r} in expression: {self.expr}")
        return value

    def parse_implication(self):
        left = self.parse_or()
        if self.current() == 'implies':
            self.consume('implies')
            right = self.parse_implication()
            return (not left) or right
        return left

    def parse_or(self):
        left = self.parse_and()
        while self.current() == 'or':
            self.consume('or')
            right = self.parse_and()
            left = left or right
        return left

    def parse_and(self):
        left = self.parse_not()
        while self.current() == 'and':
            self.consume('and')
            right = self.parse_not()
            left = left and right
        return left

    def parse_not(self):
        if self.current() == 'not':
            self.consume('not')
            return not self.parse_not()
        return self.parse_atom()

    def parse_atom(self):
        token = self.current()
        if token == '(':
            self.consume('(')
            value = self.parse_implication()
            self.consume(')')
            return value
        if token == 'True':
            self.consume('True')
            return True
        if token == 'False':
            self.consume('False')
            return False
        if token is not None and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', token):
            self.consume()
            if token not in self.values:
                raise KeyError(f"Variable {token} has no assigned value")
            return self.values[token]
        raise ValueError(f"Unexpected token {token!r} in expression: {self.expr}")


def evaluate_expression(expr, values):
    parser = ExpressionParser(expr, values)
    return parser.parse()


def extract_variables(expr):
    reserved = {'and', 'or', 'not', 'implies', 'True', 'False'}
    names = re.findall(r'[A-Za-z_][A-Za-z0-9_]*', expr)
    return sorted({name for name in names if name not in reserved})


def truth_table(expr, variables):
    rows = assignments(variables)
    header = variables + ['result']
    print(' | '.join(header))
    print('-+-'.join(['-'] * len(header)))
    for row in rows:
        result = evaluate_expression(expr, row)
        print(' | '.join(str(row.get(var, '')) for var in variables) + ' | ' + str(result))


# ---- Step 4: Produce the truth table for "p or not p" and for "p and not p". Name what you see in ... ----
# p or not p is a tautology; p and not p is a contradiction.
print('Truth table for p or not p')
truth_table('p or not p', ['p'])
print('\nTruth table for p and not p')
truth_table('p and not p', ['p'])


# ---- Step 5: Write equivalent(expr1, expr2, variables) that returns True only when the two ... ----
def equivalent(expr1, expr2, variables):
    used_vars = list(dict.fromkeys(variables + extract_variables(expr1) + extract_variables(expr2)))
    for row in assignments(used_vars):
        if evaluate_expression(expr1, row) != evaluate_expression(expr2, row):
            return False
    return True


# ---- Step 6: Use it to check De Morgan’s law: not (p and q) against (not p) or (not q). ----
def de_morgans_check():
    return equivalent('not (p and q)', '(not p) or (not q)', ['p', 'q'])


# ---- Step 7: Use it to check "p implies q" against "not p or q". ----
def implication_check():
    return equivalent('p implies q', '(not p) or q', ['p', 'q'])


# ---- Step 8: Now use equivalent on E1 and E2 from your own file. If they are not equivalent, ... ----
# E1 and E2 are equivalent because r & (p or q) equals (r & p) or (r & q)


# ---- Step 9: Now test equivalent with two expressions that use different variable lists, for ... ----
# Example: compare 'p and q' with 'q and p' using union of variables.
def cross_variable_check():
    return equivalent('p and q', 'q and p', ['p', 'q', 'r'])


# ==================================================================== THE STAMP -- DO NOT EDIT
# Computed from YOUR parameters and the answer YOUR OWN code produced. Run this last, and put the
# printed line in stamp.txt.
def stamp(student_no, activity, *values):
    payload = '|'.join([str(student_no).strip(), str(activity)] + [repr(v) for v in values])
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()[:10].upper()


def witness_for(expr1, expr2, variables):
    used_vars = list(dict.fromkeys(variables + extract_variables(expr1) + extract_variables(expr2)))
    for row in assignments(used_vars):
        if evaluate_expression(expr1, row) != evaluate_expression(expr2, row):
            return ','.join(f"{var}={str(row[var]).lower()}" for var in sorted(used_vars))
    return 'none'


if __name__ == '__main__':
    # verdict  -> True or False: does YOUR equivalent() say E1 and E2 agree everywhere?
    # witness  -> if they differ, the row where they differ, in the shape "x=False,y=True"
    #             -- YOUR OWN variable names, in alphabetical order.
    #             The string "none" if they are equivalent.
    verdict = equivalent(E1, E2, VARIABLES)
    witness = 'none' if verdict else witness_for(E1, E2, VARIABLES)
    print(stamp(STUDENT_NO, 2, E1, E2, verdict, witness))
