"""Logical operators and a recursive evaluator for IT 405L Activity 1."""


def my_and(a, b):
    return bool(a) and bool(b)


def my_or(a, b):
    return bool(a) or bool(b)


def my_not(a):
    return not bool(a)


def my_implies(a, b):
    return not bool(a) or bool(b)


def evaluate(expr):
    if not isinstance(expr, tuple):
        return bool(expr)
    if not expr:
        raise ValueError("An expression tuple cannot be empty")

    operator = expr[0]
    if operator == "not":
        if len(expr) != 2:
            raise ValueError("'not' takes exactly one operand")
        return my_not(evaluate(expr[1]))
    if operator in ("and", "or", "implies"):
        if len(expr) != 3:
            raise ValueError(f"'{operator}' takes exactly two operands")
        left = evaluate(expr[1])
        if operator == "and":
            return left and evaluate(expr[2])
        if operator == "or":
            return left or evaluate(expr[2])
        return not left or evaluate(expr[2])
    raise ValueError(f"Unknown logical operator: {operator!r}")
