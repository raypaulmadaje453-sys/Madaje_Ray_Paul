# -*- coding: utf-8 -*-
"""IT 405L  --  LABORATORY ACTIVITY 3
A Rule Engine -- Facts, Rules, Queries and Backward Chaining

    Madaje, Ray Paul E.
    2310104-1        slip A03-4        Section A        Group A03

THE VALUES BELOW ARE YOURS ALONE. A classmate may help you understand the work; a classmate
cannot answer it for you, because their answer belongs to their parameters, not to yours.

HOW TO USE THIS FILE
    1. Keep it in the same folder as the code you write. Your activity sheet names that file.
    2. Write your code there, following the steps on your sheet. The markers below are for your
       own notes.
    3. Run THIS file last:   python IT405_A03_2310104-1.py
       It imports your code, computes your stamp and prints one line. Put that line in stamp.txt.

Until you have written the function named at the bottom of this file, running it reports
ModuleNotFoundError or NameError. That is expected -- there is nothing to import yet.

It needs nothing but Python: no internet, no administrator rights and no installation, so it
behaves the same on a laboratory computer, on a borrowed laptop and on your own machine.
"""
import hashlib
from rules import add_fact, configure, matches, query


# ==================================================================== YOUR PARAMETERS
STUDENT_NO = '2310104-1'

# Your eight family facts.
FACTS = [
    ('carl', 'elle'),
    ('carl', 'gina'),
    ('carl', 'jom'),
    ('jom', 'tino'),
    ('gina', 'ben'),
    ('jom', 'sela'),
    ('ben', 'uma'),
    ('gina', 'dina'),
]

# The fact step 8 adds.
STEP8 = ('jom', 'jom')


# ==================================================================== YOUR WORK

PARENT_FACTS = [("parent", parent, child) for parent, child in FACTS]
RULES = [
    (
        ("grandparent", "X", "Z"),
        [("parent", "X", "Y"), ("parent", "Y", "Z")],
    ),
    (("ancestor", "X", "Z"), [("parent", "X", "Z")]),
    (
        ("ancestor", "X", "Z"),
        [("parent", "X", "Y"), ("ancestor", "Y", "Z")],
    ),
]
configure(PARENT_FACTS, RULES)


def pairs(answers, first, second):
    return tuple(sorted((answer[first], answer[second]) for answer in answers))


def step3_result():
    results = []
    for fact in PARENT_FACTS:
        result = matches(("parent", "X", "ben"), fact)
        if result is not None:
            results.append(result)
    return results


# ==================================================================== THE STAMP -- DO NOT EDIT
# Computed from YOUR parameters and the answer YOUR OWN code produced. Run this last, and put the
# printed line in stamp.txt.
def stamp(student_no, activity, *values):
    payload = '|'.join([str(student_no).strip(), str(activity)] + [repr(v) for v in values])
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()[:10].upper()


if __name__ == '__main__':
    print('Step 3 matches:', step3_result())
    grandparents = pairs(query(('grandparent', 'X', 'Z')), 'X', 'Z')
    print('Grandparents:', grandparents)

    ancestors_before_step8 = pairs(query(('ancestor', 'X', 'Z')), 'X', 'Z')
    print('Ancestors before STEP8:', ancestors_before_step8)

    add_fact(('parent', STEP8[0], STEP8[1]))
    ancestors_after_step8 = pairs(query(('ancestor', 'X', 'Z')), 'X', 'Z')
    print('Ancestors after STEP8:', ancestors_after_step8)

    print(stamp(STUDENT_NO, 3, tuple(tuple(f) for f in FACTS), grandparents))
