# Activity 03 Results

## Step 3: Matching

The query pattern `("parent", "X", "ben")` matches the fact `("parent", "gina", "ben")`, so the binding is:

```text
{'X': 'gina'}
```

## Step 6: Grandparents

Using `grandparent(X, Z) :- parent(X, Y), parent(Y, Z)`, the sorted results are:

```text
(('carl', 'ben'), ('carl', 'dina'), ('carl', 'sela'), ('carl', 'tino'), ('gina', 'uma'))
```

Carl is grandparent of Ben and Dina through Gina, and of Sela and Tino through Jom. Gina is grandparent of Uma through Ben.

## Steps 7-8: Ancestors and the Cycle

Before adding `STEP8`, the sorted ancestor results are:

```text
(('ben', 'uma'), ('carl', 'ben'), ('carl', 'dina'), ('carl', 'elle'), ('carl', 'gina'), ('carl', 'jom'), ('carl', 'sela'), ('carl', 'tino'), ('carl', 'uma'), ('gina', 'ben'), ('gina', 'dina'), ('gina', 'uma'), ('jom', 'sela'), ('jom', 'tino'))
```

After adding the fact `('parent', 'jom', 'jom')`, the sorted results are:

```text
(('ben', 'uma'), ('carl', 'ben'), ('carl', 'dina'), ('carl', 'elle'), ('carl', 'gina'), ('carl', 'jom'), ('carl', 'sela'), ('carl', 'tino'), ('carl', 'uma'), ('gina', 'ben'), ('gina', 'dina'), ('gina', 'uma'), ('jom', 'jom'), ('jom', 'sela'), ('jom', 'tino'))
```

The new fact makes Jom an ancestor of himself. Without cycle handling, the recursive rule can repeatedly try to prove `ancestor(jom, Z)` through `parent(jom, jom)`, eventually causing unbounded recursion. The engine prevents that by tracking goals active on the current search path; if a goal repeats, that branch stops. Fresh variable names are normalized when comparing goals. Thus the query terminates, includes `('jom', 'jom')`, and still finds the other ancestor pairs.

## Stamp

```text
89DEAB231B
```
