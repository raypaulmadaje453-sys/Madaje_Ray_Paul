"""Unification and backward-chaining helpers for Activity 03."""

from itertools import count


FACT_BASE = []
RULES = []
_rule_scopes = count(1)


def configure(facts, rules):
    global FACT_BASE, RULES
    FACT_BASE = list(facts)
    RULES = list(rules)


def add_fact(fact):
    FACT_BASE.append(fact)


def _is_variable(term):
    return isinstance(term, str) and bool(term) and term[0].isupper()


def _resolve(term, bindings):
    seen = set()
    while _is_variable(term) and term in bindings and term not in seen:
        seen.add(term)
        term = bindings[term]
    if isinstance(term, tuple):
        return tuple(_resolve(part, bindings) for part in term)
    return term


def _cycle_key(goal, bindings):
    variable_slots = {}

    def normalize(term):
        term = _resolve(term, bindings)
        if _is_variable(term):
            if term not in variable_slots:
                variable_slots[term] = len(variable_slots)
            return ("variable", variable_slots[term])
        if isinstance(term, tuple):
            return tuple(normalize(part) for part in term)
        return term

    return normalize(goal)


def _unify(pattern, fact, bindings):
    pattern = _resolve(pattern, bindings)
    fact = _resolve(fact, bindings)

    if pattern == fact:
        return dict(bindings)
    if _is_variable(pattern):
        result = dict(bindings)
        result[pattern] = fact
        return result
    if _is_variable(fact):
        result = dict(bindings)
        result[fact] = pattern
        return result
    if isinstance(pattern, tuple) and isinstance(fact, tuple):
        if len(pattern) != len(fact):
            return None
        result = dict(bindings)
        for pattern_part, fact_part in zip(pattern, fact):
            result = _unify(pattern_part, fact_part, result)
            if result is None:
                return None
        return result
    return None


def matches(pattern, fact):
    """Return consistent variable bindings, or None when terms do not match."""
    return _unify(pattern, fact, {})


def _freshen(rule):
    scope = next(_rule_scopes)
    variable_names = {}

    def freshen_term(term):
        if _is_variable(term):
            if term not in variable_names:
                variable_names[term] = f"V{scope}_{term}"
            return variable_names[term]
        if isinstance(term, tuple):
            return tuple(freshen_term(part) for part in term)
        return term

    head, conditions = rule
    return freshen_term(head), [freshen_term(condition) for condition in conditions]


def _solve(goal, bindings, active_goals):
    resolved_goal = _resolve(goal, bindings)
    goal_key = _cycle_key(goal, bindings)
    if goal_key in active_goals:
        return []

    active_goals = active_goals + (goal_key,)
    solutions = []

    for fact in FACT_BASE:
        result = _unify(resolved_goal, fact, bindings)
        if result is not None:
            solutions.append(result)

    for rule in RULES:
        head, conditions = _freshen(rule)
        result = _unify(resolved_goal, head, bindings)
        if result is None:
            continue

        partial_solutions = [result]
        for condition in conditions:
            next_solutions = []
            for partial in partial_solutions:
                next_solutions.extend(_solve(condition, partial, active_goals))
            partial_solutions = next_solutions
            if not partial_solutions:
                break
        solutions.extend(partial_solutions)

    return solutions


def _variables_in(term):
    if _is_variable(term):
        yield term
    elif isinstance(term, tuple):
        for part in term:
            yield from _variables_in(part)


def query(goal):
    """Return unique bindings for goal, searching facts before rules."""
    goal_variables = list(dict.fromkeys(_variables_in(goal)))
    answers = []
    seen_answers = set()

    for solution in _solve(goal, {}, ()):
        answer = {
            variable: _resolve(variable, solution)
            for variable in goal_variables
            if _resolve(variable, solution) != variable
        }
        answer_key = tuple(answer.items())
        if answer_key not in seen_answers:
            seen_answers.add(answer_key)
            answers.append(answer)

    return answers