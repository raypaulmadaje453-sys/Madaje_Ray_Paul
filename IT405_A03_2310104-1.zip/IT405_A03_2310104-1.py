# -*- coding: utf-8 -*-
"""Paul's Activity 03 facts, rules, query outputs, and stamp runner."""

import hashlib

from rules import add_fact, configure, matches, query


STUDENT_NO = "2310104-1"

FACTS = [
    ("carl", "elle"),
    ("carl", "gina"),
    ("carl", "jom"),
    ("jom", "tino"),
    ("gina", "ben"),
    ("jom", "sela"),
    ("ben", "uma"),
    ("gina", "dina"),
]

STEP8 = ("jom", "jom")
PARENT_FACTS = [("parent", parent, child) for parent, child in FACTS]

RULES = [
    (
        ("grandparent", "X", "Z"),
        [("parent", "X", "Y"), ("parent", "Y", "Z")],
    ),
    (("ancestor", "X", "Z"), [("parent", "X", "Z")]),
    (
        ("ancestor", "X", "Z"),
        [("parent", "X", "Y"), ("ancestor", "Y", "Z")],
    ),
]

configure(PARENT_FACTS, RULES)


def _pairs(answers, first, second):
    return tuple(sorted((answer[first], answer[second]) for answer in answers))


def stamp(student_no, activity, *values):
    payload = "|".join(
        [str(student_no).strip(), str(activity)] + [repr(value) for value in values]
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:10].upper()


if __name__ == "__main__":
    match_test = [
        matches(("parent", "X", "ben"), fact)
        for fact in PARENT_FACTS
    ]
    print("Step 3 matches:", [result for result in match_test if result is not None])

    grandparents = _pairs(query(("grandparent", "X", "Z")), "X", "Z")
    print("Grandparents:", grandparents)

    ancestors_before_step8 = _pairs(query(("ancestor", "X", "Z")), "X", "Z")
    print("Ancestors before STEP8:", ancestors_before_step8)

    add_fact(("parent", STEP8[0], STEP8[1]))
    ancestors_after_step8 = _pairs(query(("ancestor", "X", "Z")), "X", "Z")
    print("Ancestors after STEP8:", ancestors_after_step8)

    print(
        stamp(
            STUDENT_NO,
            3,
            tuple(tuple(fact) for fact in FACTS),
            grandparents,
        )
    )