# Activity 03 Answers

## Step 3: Match

Matching `("parent", "X", "ben")` against the eight parent facts returns:

```text
{'X': 'gina'}
```

## Step 6: Grandparents

The rule is `grandparent(X, Z) :- parent(X, Y), parent(Y, Z)`. The sorted answers are:

```text
(('carl', 'ben'), ('carl', 'dina'), ('carl', 'sela'), ('carl', 'tino'), ('gina', 'uma'))
```

Carl is grandparent of Ben and Dina through Gina, and of Sela and Tino through Jom. Gina is Uma's grandparent through Ben.

## Steps 7-8: Ancestors

Before adding `STEP8`, the sorted ancestor pairs are:

```text
(('ben', 'uma'), ('carl', 'ben'), ('carl', 'dina'), ('carl', 'elle'), ('carl', 'gina'), ('carl', 'jom'), ('carl', 'sela'), ('carl', 'tino'), ('carl', 'uma'), ('gina', 'ben'), ('gina', 'dina'), ('gina', 'uma'), ('jom', 'sela'), ('jom', 'tino'))
```

After adding `('jom', 'jom')`, the query completes with:

```text
(('ben', 'uma'), ('carl', 'ben'), ('carl', 'dina'), ('carl', 'elle'), ('carl', 'gina'), ('carl', 'jom'), ('carl', 'sela'), ('carl', 'tino'), ('carl', 'uma'), ('gina', 'ben'), ('gina', 'dina'), ('gina', 'uma'), ('jom', 'jom'), ('jom', 'sela'), ('jom', 'tino'))
```

The self-parent fact makes the recursive ancestor rule revisit the same goal for Jom. A basic depth-first engine without cycle handling would keep recursing on that branch. This solution tracks goals already active on the current search path, treating fresh variable names as equivalent; when a goal repeats, it stops that branch. The other branches still produce Jom's descendants. This is one way to make the search survive the cycle.

## Stamp

```text
89DEAB231B
```
